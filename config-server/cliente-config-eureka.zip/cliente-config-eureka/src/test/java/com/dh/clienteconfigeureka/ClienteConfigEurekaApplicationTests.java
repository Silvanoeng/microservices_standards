package com.dh.clienteconfigeureka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClienteConfigEurekaApplicationTests {

	@Test
	void contextLoads() {
	}

}
